var config = {
	config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'MGS_ExtraGallery/js/configurable': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'MGS_ExtraGallery/js/swatch-renderer': true
            }
        }
    }
};