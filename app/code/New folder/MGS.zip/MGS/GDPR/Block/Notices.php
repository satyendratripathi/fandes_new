<?php

namespace MGS\GDPR\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;


class Notices extends \Magento\Cookie\Block\Html\Notices{
	
}
?>