<?php

namespace MGS\Lookbook\Controller\Adminhtml\Lookbookslide;

class ItemsGrid extends Items
{

}