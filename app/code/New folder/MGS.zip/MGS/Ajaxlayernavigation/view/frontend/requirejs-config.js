var config = {
 config: {
     mixins: {
         'Smile_ElasticsuiteCatalog/js/range-slider-widget': {
			'MGS_Ajaxlayernavigation/js/range-slider-widget': true
		}
     }
 }
};