# Lof Setup Extension

Import sample data, transfer data for landofcoder extensions

## 1. Documentation

## 2. How to install Lof Setup Extension

### Install via composer (recommend)

Run the following command in Magento 2 root folder:

```
composer require landofcoder/module-setup
php bin/magento setup:upgrade
php bin/magento setup:static-content:deploy
```