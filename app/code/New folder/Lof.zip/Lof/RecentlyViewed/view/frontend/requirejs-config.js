var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/product/list/listing': {
                'Lof_RecentlyViewed/js/product/list/listing-mixin': true
            }
        }
    }
    
};
