var config = {
	paths: {
		'lof/notifyslider'			: 'Lof_RecentOrder/js/notifyslider'
	},

	shim: {
		'lof/notifyslider': {
			deps: ['jquery']
		}
	}

};